#include "at24cxx.h"
#include <string.h>

void AT24C256_WriteByte(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t data) {
    HAL_I2C_Mem_Write(hi2c, AT24C256_I2C_ADDRESS, memAddr, I2C_MEMADD_SIZE_16BIT, &data, 1, HAL_MAX_DELAY);
    while (HAL_I2C_IsDeviceReady(hi2c, AT24C256_I2C_ADDRESS, 10, HAL_MAX_DELAY) != HAL_OK);
}

uint8_t AT24C256_ReadByte(I2C_HandleTypeDef *hi2c, uint16_t memAddr) {
    uint8_t data = 0;
    HAL_I2C_Mem_Read(hi2c, AT24C256_I2C_ADDRESS, memAddr, I2C_MEMADD_SIZE_16BIT, &data, 1, HAL_MAX_DELAY);
    return data;
}

void AT24C256_WriteBuffer(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *data, uint16_t length) {
    for (uint16_t i = 0; i < length; i++) {
        AT24C256_WriteByte(hi2c, memAddr + i, data[i]);
    }
}

void AT24C256_ReadBuffer(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *data, uint16_t length) {
    for (uint16_t i = 0; i < length; i++) {
        data[i] = AT24C256_ReadByte(hi2c, memAddr + i);
    }
}

HAL_StatusTypeDef AT24C256_WritePage(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *data, uint16_t length)
{
    if (length > AT24C256_PAGE_SIZE) return HAL_ERROR;

    // Ensure write doesn't cross page boundary
    if ((memAddr % AT24C256_PAGE_SIZE) + length > AT24C256_PAGE_SIZE)
        return HAL_ERROR;

    HAL_StatusTypeDef status = HAL_I2C_Mem_Write(
        hi2c,
        AT24C256_I2C_ADDRESS,
        memAddr,
        I2C_MEMADD_SIZE_16BIT,
        data,
        length,
        HAL_MAX_DELAY
    );

    // Wait for internal write cycle (~5ms)
    if (status == HAL_OK) {
        while (HAL_I2C_IsDeviceReady(hi2c, AT24C256_I2C_ADDRESS, 10, HAL_MAX_DELAY) != HAL_OK);
    }

    return status;
}

HAL_StatusTypeDef AT24C256_ReadPage(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *buffer, uint16_t length)
{
    if (length > AT24C256_PAGE_SIZE) return HAL_ERROR;

    return HAL_I2C_Mem_Read(
        hi2c,
        AT24C256_I2C_ADDRESS,
        memAddr,
        I2C_MEMADD_SIZE_16BIT,
        buffer,
        length,
        HAL_MAX_DELAY
    );
}
