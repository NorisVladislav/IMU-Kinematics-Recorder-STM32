#include "mpu6050.h"
#include <stdio.h>    // pentru printf, dacă folosești UART pentru debug
#include <stdint.h>   // pentru uint8_t, int16_t

#define MPU6050_PWR_MGMT_1     0x6B
#define MPU6050_ACCEL_XOUT_H   0x3B

HAL_StatusTypeDef MPU6050_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t data = 0;
    return HAL_I2C_Mem_Write(hi2c, MPU6050_ADDR, MPU6050_PWR_MGMT_1, 1, &data, 1, HAL_MAX_DELAY);
}

void MPU6050_Read_XYZ(I2C_HandleTypeDef *hi2c, int16_t *ax, int16_t *ay, int16_t *az,
                      int16_t *gx, int16_t *gy, int16_t *gz) {
    uint8_t buf[14];

    if (HAL_I2C_Mem_Read(hi2c, MPU6050_ADDR, MPU6050_ACCEL_XOUT_H, 1, buf, 14, HAL_MAX_DELAY) == HAL_OK) {
        *ax = (int16_t)(buf[0] << 8 | buf[1]);
        *ay = (int16_t)(buf[2] << 8 | buf[3]);
        *az = (int16_t)(buf[4] << 8 | buf[5]);
        *gx = (int16_t)(buf[8] << 8 | buf[9]);
        *gy = (int16_t)(buf[10] << 8 | buf[11]);
        *gz = (int16_t)(buf[12] << 8 | buf[13]);
    } else {
        printf("Eroare la citirea MPU6050\r\n");
    }
}
