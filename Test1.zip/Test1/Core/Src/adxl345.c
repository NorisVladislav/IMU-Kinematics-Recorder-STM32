#include "adxl345.h"
#include "stdio.h"

void ADXL345_Init(I2C_HandleTypeDef *hi2c) {
    uint8_t data = 0x08;
    HAL_I2C_Mem_Write(hi2c, ADXL345_ADDR, ADXL345_POWER_CTL, 1, &data, 1, HAL_MAX_DELAY);
    HAL_I2C_Mem_Write(hi2c, ADXL345_ADDR, ADXL345_DATA_FORMAT, 1, &data, 1, HAL_MAX_DELAY);
}

void ADXL345_Read_XYZ(I2C_HandleTypeDef *hi2c, int16_t *x, int16_t *y, int16_t *z) {
    uint8_t buf[6];
    if (HAL_I2C_Mem_Read(hi2c, ADXL345_ADDR, ADXL345_DATAX0, 1, buf, 6, HAL_MAX_DELAY) == HAL_OK) {
        *x = (int16_t)(buf[1] << 8 | buf[0]);
        *y = (int16_t)(buf[3] << 8 | buf[2]);
        *z = (int16_t)(buf[5] << 8 | buf[4]);
    } else {
        printf("Eroare la citirea ADXL345\r\n");
    }
}