#ifndef __AT24C256_H__
#define __AT24C256_H__

#include "stm32f1xx_hal.h"
#include <stdint.h>

#define AT24C256_I2C_ADDRESS  (0x50 << 1)  // Default base address
#define AT24C256_PAGE_SIZE    64           // Page size in bytes

void AT24C256_WriteByte(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t data);
uint8_t AT24C256_ReadByte(I2C_HandleTypeDef *hi2c, uint16_t memAddr);
void AT24C256_WriteBuffer(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *data, uint16_t length);
void AT24C256_ReadBuffer(I2C_HandleTypeDef *hi2c, uint16_t memAddr, uint8_t *data, uint16_t length);
HAL_StatusTypeDef AT24C256_WritePage(I2C_HandleTypeDef *hi2c, uint16_t mem_address, uint8_t *data, uint16_t length);
HAL_StatusTypeDef AT24C256_ReadPage(I2C_HandleTypeDef *hi2c, uint16_t mem_address, uint8_t *buffer, uint16_t length);

#endif // __AT24C256_H__