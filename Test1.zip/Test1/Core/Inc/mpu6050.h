#ifndef MPU6050_H
#define MPU6050_H

#include <stdint.h>
#include "stm32f1xx_hal.h"

#define MPU6050_ADDR 0x68 << 1

typedef struct {
    int16_t Accel_X;
    int16_t Accel_Y;
    int16_t Accel_Z;
    int16_t Gyro_X;
    int16_t Gyro_Y;
    int16_t Gyro_Z;
    int16_t Temp;
} MPU6050_Data;

HAL_StatusTypeDef MPU6050_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef MPU6050_Read_All(I2C_HandleTypeDef *hi2c, MPU6050_Data *data);

// ✅ Noua funcție tip ADXL345:
void MPU6050_Read_XYZ(I2C_HandleTypeDef *hi2c,
                      int16_t *ax, int16_t *ay, int16_t *az,
                      int16_t *gx, int16_t *gy, int16_t *gz);

#endif
