#ifndef __ADXL345_H__
#define __ADXL345_H__

#include "stm32f1xx_hal.h"

#define ADXL345_ADDR         (0x53 << 1)
#define ADXL345_POWER_CTL    0x2D
#define ADXL345_DATA_FORMAT  0x31
#define ADXL345_DATAX0       0x32

void ADXL345_Init(I2C_HandleTypeDef *hi2c);
void ADXL345_Read_XYZ(I2C_HandleTypeDef *hi2c, int16_t *x, int16_t *y, int16_t *z);

#endif // __ADXL345_H__